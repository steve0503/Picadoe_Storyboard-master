//
//  main.m
//  CameraTest
//
//  Created by 이 해용 on 2014. 1. 14..
//  Copyright (c) 2014년 iamdreamer. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
