//
//  CameraViewController.h
//  CameraTest
//
//  Created by SDT-1 on 2014. 1. 14..
//  Copyright (c) 2014년 iamdreamer. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CameraViewController : UIViewController < UIImagePickerControllerDelegate, UINavigationControllerDelegate>

@end
