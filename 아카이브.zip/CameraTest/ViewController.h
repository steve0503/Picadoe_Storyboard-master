//
//  ViewController.h
//  CameraTest
//
//  Created by 이 해용 on 2014. 1. 14..
//  Copyright (c) 2014년 iamdreamer. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
